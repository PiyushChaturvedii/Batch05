export const CartCard = () => {
  return (
    <div>CartCard</div>
  )
}
