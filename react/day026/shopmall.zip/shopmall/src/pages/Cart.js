export const Cart = () => {
  return (
    <div>Cart</div>
  )
}
