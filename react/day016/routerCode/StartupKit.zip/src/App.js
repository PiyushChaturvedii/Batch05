import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Shree Ram</h1>
    </div>
  );
}

export default App;
