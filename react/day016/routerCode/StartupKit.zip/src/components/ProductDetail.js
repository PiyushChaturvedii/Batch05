export const ProductDetail = () => {
  return (
    <div>ProductDetail</div>
  )
}
